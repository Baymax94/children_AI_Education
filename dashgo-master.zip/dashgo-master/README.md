EAI dashgo D1
