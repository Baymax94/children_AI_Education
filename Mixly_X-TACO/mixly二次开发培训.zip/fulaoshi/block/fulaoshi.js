'use strict';

goog.provide('Blockly.Blocks.fulaoshi');

goog.require('Blockly.Blocks');


Blockly.Blocks.dfrobot.HUE = 20;



Blockly.Blocks.fulaoshi_led={
init:function(){
    
  }
};
Blockly.Blocks.fulaoshi_666={
init:function(){

  }
};