'use strict';

goog.provide('Blockly.Arduino.fulaoshi');

goog.require('Blockly.Arduino');

Blockly.Arduino.fulaoshi_led=function(){
   
};
Blockly.Arduino.fulaoshi_666=function(){
   
};