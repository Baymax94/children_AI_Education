alert("这是我的第一个JavaScript程序")；
console.log("欢迎来到JavaScript世界")；